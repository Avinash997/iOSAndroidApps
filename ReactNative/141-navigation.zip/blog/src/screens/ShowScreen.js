import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

const ShowScreen = () => {
  return (
    <View>
      <Text>Show Screen</Text>
    </View>
  );
};

const styles = StyleSheet.create({});

export default ShowScreen;
