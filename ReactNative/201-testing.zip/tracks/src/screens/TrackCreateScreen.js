import React from 'react';
import { View, StyleSheet, Text } from 'react-native';

const TrackCreateScreen = () => {
  return <Text style={{ fontSize: 48 }}>TrackCreateScreen</Text>;
};

const styles = StyleSheet.create({});

export default TrackCreateScreen;
