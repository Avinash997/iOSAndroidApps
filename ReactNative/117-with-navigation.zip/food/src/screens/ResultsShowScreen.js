import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

const ResultsShowScreen = () => {
  return (
    <View>
      <Text>Results Show</Text>
    </View>
  );
};

const styles = StyleSheet.create({});

export default ResultsShowScreen;
