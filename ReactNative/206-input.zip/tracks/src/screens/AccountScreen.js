import React from 'react';
import { View, StyleSheet, Text } from 'react-native';

const AccountScreen = () => {
  return <Text style={{ fontSize: 48 }}>AccountScreen</Text>;
};

const styles = StyleSheet.create({});

export default AccountScreen;
