export const FACEBOOK_LOGIN_SUCCESS = 'facebook_login_success';
export const FACEBOOK_LOGIN_FAIL = 'facebook_login_fail';
export const FETCH_JOBS = 'fetch_jobs';
export const LIKE_JOB = 'like_job';
export const CLEAR_LIKED_JOBS = 'clear_liked_jobs';
