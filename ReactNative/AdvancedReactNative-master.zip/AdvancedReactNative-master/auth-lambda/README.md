### Auth-Lambda

This is an alternative implementation of the one time password app that uses AWS Lambda and [Serverless](https://serverless.com/) rather than Google Cloud Functions.

The code may or may not work as is - it is provided here as a reference.
