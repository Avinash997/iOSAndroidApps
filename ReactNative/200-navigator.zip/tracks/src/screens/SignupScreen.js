import React from 'react';
import { View, StyleSheet, Text } from 'react-native';

const SignupScreen = () => {
  return <Text style={{ fontSize: 48 }}>SignupScreen</Text>;
};

const styles = StyleSheet.create({});

export default SignupScreen;
