import React from 'react';
import { View, StyleSheet, Text } from 'react-native';

const TrackListScreen = () => {
  return <Text style={{ fontSize: 48 }}>TrackListScreen</Text>;
};

const styles = StyleSheet.create({});

export default TrackListScreen;
