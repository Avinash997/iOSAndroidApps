import React from 'react';
import { View, StyleSheet, Text } from 'react-native';

const SigninScreen = () => {
  return <Text style={{ fontSize: 48 }}>SigninScreen</Text>;
};

const styles = StyleSheet.create({});

export default SigninScreen;
