import axios from "axios";

export default axios.create({
  baseURL: "ENTER_YOUR_OWN_TUNNEL_ADDRESS",
});
